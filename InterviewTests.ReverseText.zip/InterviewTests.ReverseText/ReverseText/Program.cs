﻿using System;
using System.Linq;
using System.IO;
using System.Collections.Generic;
using System.Text;

namespace ReverseText
{
    // IMPORTANT: make sure you read the instructions in README.md

    class Program
    {
        static void Main(string[] args)
        {
            const string filePath = "TestTextFile.txt";

            FileTextReverser ftr = new FileTextReverser();
            string text = ftr.ReverseFileContents(filePath);

            Console.WriteLine(text);
        }
    }

    public interface IFile    {
        StreamReader StreamReader(string path);
    }

    public class FileTextReverser
    {
        IFile fileManager;

        public FileTextReverser()
        {
        }

        public FileTextReverser(IFile fileManager)
        {
            this.fileManager = fileManager;
        }
        public string ReverseFileContents(string filePath)
        {
            // TODO: read text file, reverse the text, save reversed text back to the same file

            string str = File.ReadAllText(filePath);
            string[] words = str.Split(' ');

            //   // Approach 1 using linq
            //   var reversedWords = string.Join(" ",
            //   str.Split(' ')
            //.Select(x => new String(x.Reverse().ToArray()))
            //.ToArray());

            //   File.WriteAllText(filePath, reversedWords);

            //   // TODO: return the reversed text
            //   string output = reversedWords;

            // Approach 2 using Stack
            Stack<char> st = new Stack<char>();
            StringBuilder resultStr = new StringBuilder();

            // Traverse given string and push  
            // all characters to stack until 
            // we see a space.  
            for (int i = 0; i < str.Length; ++i)
            {
                if (str[i] != ' ')
                {
                    st.Push(str[i]);
                }

                // When we see a space, we  
                // print contents of stack.  
                else
                {
                    while (st.Count > 0)
                    {
                        resultStr.Append(st.Pop());

                    }
                    resultStr.Append(" ");
                }
            }

            // Since there may not be  
            // space after last word.  
            while (st.Count > 0)
            {
                resultStr.Append(st.Pop());
            }

            File.WriteAllText(filePath, resultStr.ToString());

            // TODO: return the reversed text
            string output = resultStr.ToString();

            return output;
        }
    }
}
