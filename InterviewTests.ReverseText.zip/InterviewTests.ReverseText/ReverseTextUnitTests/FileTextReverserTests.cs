using Microsoft.Practices.EnterpriseLibrary.Common.Utility;
using NUnit.Framework;
using ReverseText;
using System.IO;
using System.Linq;
using System.Reflection;
using Moq;

namespace ReverseTextUnitTests
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public void FileTextReverser()
        {            
            Mock<IFile> mockFileManager = new Mock<IFile>();
            string fakeFileContents = "sihT si emos txet rof eht tset";
            //string fakeFileContents = "This is some text for the test";

            byte[] fakeFileBytes = System.Text.Encoding.UTF8.GetBytes(fakeFileContents);
            MemoryStream fakeMemoryStream = new MemoryStream(fakeFileBytes);

            mockFileManager.Setup(fileManager => fileManager.StreamReader(It.IsAny<string>()))
                           .Returns(() => new StreamReader(fakeMemoryStream));

            FileTextReverser foo = new FileTextReverser(mockFileManager.Object);

            string result = foo.ReverseFileContents("TestTextFile.txt");
            // doesn't hit the underlying filesystem!!!          
         
            Assert.AreEqual(fakeFileContents, result);          
            //Assert.Pass();
        }       
    }
}